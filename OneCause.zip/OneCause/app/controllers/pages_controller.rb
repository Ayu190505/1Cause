class PagesController < ApplicationController
  def home
  end

  def donor_login_select
  end

  def donor
  end

  def charity
  end

  def login
  end

  def donordashboard
  end

  def charitydashboard
  end

  def payment
  end

  def rationale
  end

  
end
