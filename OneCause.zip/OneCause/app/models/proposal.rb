class Proposal < ApplicationRecord
end
